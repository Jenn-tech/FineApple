/**
 * 
 */
 
var modal = function() {

 	document.getElementById("agree-id").onclick = function() {
        document.getElementById("modal").style.display="block";
    }
    
     document.getElementById("modal_close_btn").onclick = function() {
        document.getElementById("modal").style.display="none";
    }    
    
    /*arg */
    	document.getElementById("agree-id").onclick = function() {
        document.getElementById("modal").style.display="block";
    }
    
     document.getElementById("modal_close_btn").onclick = function() {
        document.getElementById("modal").style.display="none";
    }    
    
    	document.getElementById("agree-id").onclick = function() {
        document.getElementById("modal").style.display="block";
    }
    
     document.getElementById("modal_close_btn").onclick = function() {
        document.getElementById("modal").style.display="none";
    }    
}

