package review;

public class ReviewVo {
	int reviewSerial;
	String memberId;
	String reviewTitle;
	String reviewDate;
	String reviewDoc;
	String productName;
	String reviewCategory;
	String reviewImg;
	int reviewAvailable;
	
	
	
	public int getReviewSerial() {
		return reviewSerial;
	}
	public void setReviewSerial(int reviewSerial) {
		this.reviewSerial = reviewSerial;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public String getReviewTitle() {
		return reviewTitle;
	}
	public void setReviewTitle(String reviewTitle) {
		this.reviewTitle = reviewTitle;
	}
	public String getReviewDate() {
		return reviewDate;
	}
	public void setReviewDate(String reviewDate) {
		this.reviewDate = reviewDate;
	}
	public String getReviewDoc() {
		return reviewDoc;
	}
	public void setReviewDoc(String reviewDoc) {
		this.reviewDoc = reviewDoc;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getReviewCategory() {
		return reviewCategory;
	}
	public void setReviewCategory(String reviewCategory) {
		this.reviewCategory = reviewCategory;
	}
	public String getReviewImg() {
		return reviewImg;
	}
	public void setReviewImg(String reviewImg) {
		this.reviewImg = reviewImg;
	}
	public int getReviewAvailable() {
		return reviewAvailable;
	}
	public void setReviewAvailable(int i) {
		this.reviewAvailable = i;
	}
	
	
}
