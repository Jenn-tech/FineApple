package notice;

public class NoticeVo {
	int noticeNo ;
	String noticeSubject ;
	String  noticeDoc ;
	String  noticeDate ;
	int    noticeHit ;
	public int getNoticeNo() {
		return noticeNo;
	}
	public void setNoticeNo(int noticeNo) {
		this.noticeNo = noticeNo;
	}
	public String getNoticeSubject() {
		return noticeSubject;
	}
	public void setNoticeSubject(String noticeSubject) {
		this.noticeSubject = noticeSubject;
	}
	public String getNoticeDoc() {
		return noticeDoc;
	}
	public void setNoticeDoc(String noticeDoc) {
		this.noticeDoc = noticeDoc;
	}
	public String getNoticeDate() {
		return noticeDate;
	}
	public void setNoticeDate(String noticeDate) {
		this.noticeDate = noticeDate;
	}
	public int getNoticeHit() {
		return noticeHit;
	}
	public void setNoticeHit(int noticeHit) {
		this.noticeHit = noticeHit;
	}
	
	
}
