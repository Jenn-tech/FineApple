package users;

import java.sql.Date;

public class MemberVo {
	private int seqno;
	private String mid;
	private String pwd;
	private String name;
	private String email;
	private String phone;
	private String zipcode;
	private String address;
	private Date joindate;
	
	public int getSeqno() {
		return seqno;
	}
	public void setSeqno(int seqno) {
		this.seqno = seqno;
	}
	
	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	public Date getJoindate() {
		return joindate;
	}
	public void setJoindate(Date joindate) {
		this.joindate = joindate;
	}
	
	@Override
	public String toString() {
		return "MemberVo [seqno=" + seqno + ", mid=" + mid + ", pwd=" + pwd + ", name=" + name + ", email=" + email
				+ ", phone=" + phone + ", zipcode=" + zipcode + ", address=" + address + ", joindate=" + joindate + "]";
	}
	
}
